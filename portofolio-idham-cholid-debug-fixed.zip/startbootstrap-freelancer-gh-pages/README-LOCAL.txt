PORTOFOLIO IDHAM CHOLID

Cara menjalankan:
1. Extract folder project.
2. Buka folder startbootstrap-freelancer-gh-pages di VS Code (folder yang berisi index.html).
3. Pastikan ekstensi Live Server sudah terpasang.
4. Klik kanan index.html > Open with Live Server.
5. Halaman akan terbuka di http://127.0.0.1:5500/index.html

Kontak yang ditampilkan:
Lokasi: DKI Jakarta, Indonesia
Telepon/WhatsApp: 0895-6134-6104

Catatan:
Bagian Keahlian menjelaskan area keahlian, bukan daftar proyek yang telah diverifikasi.

Background hero sekarang memakai animasi gradien gelap, grid teknologi, dan garis cahaya dengan CSS. Tidak memerlukan library tambahan.
Bagian Tentang Saya juga memakai background animasi bertema software engineering, senada dengan hero.

PERBAIKAN DEBUGGING ABOUT:BLANK
1. Buka folder project ini di VS Code (folder yang langsung berisi index.html).
2. Jalankan Live Server terlebih dahulu: klik kanan index.html > Open with Live Server.
3. Pastikan browser membuka http://127.0.0.1:5500/index.html.
4. Setelah Live Server aktif, pilih konfigurasi "Debug Portofolio Idham (Live Server)" di panel Run and Debug.
5. Tekan F5. Jangan pilih "Attach" atau konfigurasi browser lain.
Jika port Live Server bukan 5500, ubah nilai "url" di .vscode/launch.json agar sama dengan alamat Live Server.
